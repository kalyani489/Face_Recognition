# Face-Recognition-Based-Attendance-System
It's final year project of Diploma Engineering. This project is based on Computer Vision.

Brief idea about our project is mentioned in project presentation file.
You just have to run attendance.py file in your suitable IDE but we prefer jupyter lab.

Prerequisites: Web cam,
               OpenCV library,
               Tkinter module,
               Numpy, Pandas &
               PIL
               
If you get stuck anywhere feel free to ping me.
This is team work and credits goes to @Bhavin, @Dhruv & @Vivek.

Copyrights © 2021 by Neel Patel.
All rights are reserved.
